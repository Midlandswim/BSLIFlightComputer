voltage sense reference doc https://community.st.com/t5/stm32-mcus/management-of-vbus-sensing-for-usb-device-design/ta-p/49485

USB design guide https://www.st.com/resource/en/application_note/an4879-introduction-to-usb-hardware-and-pcb-guidelines-using-stm32-mcus-stmicroelectronics.pdf

Oscillator app note https://www.st.com/resource/en/application_note/cd00221665-oscillator-design-guide-for-stm8af-al-s-stm32-mcus-and-mpus-stmicroelectronics.pdf

STM32 datasheet https://www.st.com/resource/en/datasheet/stm32u575ag.pdf

Tasks:
[TO-DO] Layout
[TO-DO] CAN transceiver selection
[DONE] B-B connectors
- Harwin Geck 2x25 SMT 
[TO-DO] ESD protection
[TO-DO] Diagnostics heade (I2c, SPI, GPio, etc.)
[IN-PROGESS] Resonator Selection